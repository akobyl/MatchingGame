﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Shapes;

namespace MatchMe
{
    class matchObject
    {
        public System.Windows.Point center;
        public Ellipse circle;
        public Polygon polygon;


    }
}
